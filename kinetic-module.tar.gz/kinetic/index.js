// kinetic/index.js
// Main Kinetic integration module for CC4C

const services = require('./services');
const sessionPool = require('./utils/session-pool');
const drmDetector = require('./utils/drm-detector');
const streamInterceptor = require('./utils/stream-interceptor');
const config = require('./config/bradmini.json');

class KineticEnhancer {
  constructor() {
    this.services = services;
    this.sessionPool = sessionPool;
    this.drmDetector = drmDetector;
    this.streamInterceptor = streamInterceptor;
    this.config = config;
    this.stats = {
      streamsHandled: 0,
      customServicesUsed: 0,
      sessionsReused: 0,
      errors: 0,
    };
  }

  /**
   * Check if a URL should use custom Kinetic handling
   */
  shouldHandle(url) {
    const service = this.services.getServiceForUrl(url);
    if (!service) return false;

    const serviceConfig = this.config.services[service.name.toLowerCase().replace(/\s+/g, '-')];
    return serviceConfig && serviceConfig.enabled;
  }

  /**
   * Handle a stream request with Kinetic enhancements
   */
  async handleStream(url, browser, setupPage, getStream, encodingParams, req, res) {
    this.stats.streamsHandled++;
    
    const service = this.services.getServiceForUrl(url);
    
    if (!service) {
      throw new Error('No service handler found for URL');
    }

    console.log(`[Kinetic] Using ${service.name} handler for ${url}`);
    this.stats.customServicesUsed++;

    const serviceName = service.name.toLowerCase().replace(/\s+/g, '-');
    const serviceConfig = this.config.services[serviceName];
    
    let page;
    
    // Try to reuse session if enabled
    if (serviceConfig.sessionReuse && this.config.features.sessionPooling) {
      page = await this.sessionPool.getOrCreate(serviceName, async () => {
        console.log(`[Kinetic] Creating new authenticated session for ${service.name}`);
        const newPage = await setupPage(browser);
        await newPage.goto(url, {waitUntil: 'networkidle2', timeout: serviceConfig.timeout || 30000});
        await service.setup(newPage, url);
        return newPage;
      });
      
      if (page) {
        this.stats.sessionsReused++;
        console.log(`[Kinetic] Reusing existing session for ${service.name}`);
        
        // Just navigate to new content if URL changed
        if (page.url() !== url) {
          await page.goto(url, {waitUntil: 'networkidle2', timeout: serviceConfig.timeout || 30000});
          await service.setup(page, url);
        }
      }
    } else {
      // Create fresh page
      page = await setupPage(browser);
      await page.goto(url, {waitUntil: 'networkidle2', timeout: serviceConfig.timeout || 30000});
      await service.setup(page, url);
    }

    // Optional: Detect DRM if enabled
    if (this.config.features.drmDetection) {
      const drmInfo = await this.drmDetector.detect(page);
      console.log(`[Kinetic] DRM detection result:`, drmInfo);
    }

    // Optional: Try to intercept stream URL if enabled
    if (this.config.features.streamInterception) {
      try {
        const streamInfo = await this.streamInterceptor.extractWithAuth(page);
        if (streamInfo) {
          console.log(`[Kinetic] Extracted stream info:`, streamInfo);
          // Could potentially use this for direct streaming in the future
        }
      } catch (e) {
        console.log(`[Kinetic] Stream interception failed:`, e.message);
      }
    }

    // Start the capture stream
    const stream = await getStream(page, encodingParams);
    stream.pipe(res);

    // Handle cleanup
    req.on('close', async () => {
      console.log(`[Kinetic] Stream closed for ${service.name}`);
      stream.destroy();
      
      if (serviceConfig.sessionReuse && this.config.features.sessionPooling) {
        // Keep page alive for reuse
        this.sessionPool.release(serviceName, page);
      } else {
        // Close page immediately
        await page.close();
      }
      
      if (service.cleanup) {
        await service.cleanup(page);
      }
    });

    res.on('error', async (err) => {
      console.error(`[Kinetic] Stream error for ${service.name}:`, err.message);
      this.stats.errors++;
      stream.destroy();
      
      if (!serviceConfig.sessionReuse) {
        await page.close();
      }
    });

    return {page, stream, service};
  }

  /**
   * Get metadata for a stream
   */
  async getMetadata(url, page) {
    const service = this.services.getServiceForUrl(url);
    if (service && service.getMetadata) {
      return await service.getMetadata(page);
    }
    return null;
  }

  /**
   * Get Kinetic statistics
   */
  getStats() {
    return {
      ...this.stats,
      sessionPool: this.sessionPool.getStats(),
    };
  }

  /**
   * Cleanup all resources
   */
  async cleanup() {
    console.log('[Kinetic] Cleaning up all resources...');
    await this.sessionPool.clearAll();
  }
}

// Export singleton instance
module.exports = new KineticEnhancer();
